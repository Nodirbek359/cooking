
import { useState } from 'react';
import { Link } from 'react-router-dom';
import loginbg from '../video/login-bg.mp4'

const Login= () => {
 

  return (
    <div className="  rounded shadow-md relative bg-opacity-50  ">
    <video
      muted
      autoPlay
      loop
      className=' absolute object-cover w-screen h-screen z-[-1]' src={loginbg}></video>
        <div className=' bg-black bg-opacity-60  flex flex-col items-center  justify-center h-screen '>
      <div className='bg-white bg-opacity-40 h-100% max-w-md w-full px-10 py-4 rounded-md'>
      <h2 className="text-2xl text-center font-bold mb-4">Login</h2>
 
    <div className="mb-4">
      <label htmlFor="email" className="block text-sm font-medium text-gray-600">
        Email
      </label>
          <input
            placeholder='Your Email'
        type="email"
        id="email"
        className="mt-1 p-2 w-full border rounded-md"
        onChange={(e) => setEmail(e.target.value)}
      />
    </div>
    <div className="mb-4">
      <label htmlFor="password" className="block text-sm font-medium text-gray-600">
        Password
      </label>
          <input
            placeholder='Your Password'
        type="password"
        id="password"
        className="mt-1 p-2 w-full border rounded-md"
        onChange={(e) => setPassword(e.target.value)}
      />
    </div>
      <div className="flex  justify-between">
        <Link to='/Login' className='flex  bg-green-500 text-white p-2 rounded-md' >
        Login
            </Link>
            <button className='flex  bg-orange-400 text-white p-2 rounded-md'>Sign Up</button>
           
          </div>
          
        </div>
    </div>
  </div>
  );
};

export default Login;