import React from 'react'
import { Link } from 'react-router-dom'
import logo from '../images/logo.jpg'

function Navbar() {
  return (
      <header className=' bg-slate-400  items-center  text-center  '>
          <div className="max-container  items-center   justify-between flex  flex-col sm:oft  md:px-10 ">
         <img className='rounded-lg w-12 h-12 flex' src={logo} alt="" />
              <nav className='py-4 flex items-center   gap-3 flex-col'>
                
                  <div className='flex  items-center gap-3'>
                      <ul className='navbar  sm:flex sm:items-center sm:p-0 sm:gap-4 '>

              <li className='gap-3'>
                <Link to='/'>
                <button>Home</button>
                </Link>
              </li> <li className='pt-2'>
              <Link to='/Login' >
          <button className="animation hover:bg-green-700   bg-green-500  text-white p-2 rounded-md " >
          Login
        </button>
          </Link>
              </li><li className='pt-2'>
              <Link to='/Create' >
          <button className= "bg-orange-600 text-white p-2 rounded-md" >
Create        </button>
          </Link>
              </li>
            

                      </ul>
                   
                      
                 </div>
        </nav>
        
          </div>
     </header>
  )
}

export default Navbar