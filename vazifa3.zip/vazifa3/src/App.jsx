import { createBrowserRouter, RouterProvider, Routes } from "react-router-dom"

//compponents
import Footer from "./components/Footer"
import Navbar from "./components/Navbar"
import Mainlayout from "./layout/Mainlayout"

//pages
import Login from "./pages/Login"
import Create from "./pages/Create"
//Layout
function App() {
  const routes = createBrowserRouter([
    {
      path: '/',
      element: <Mainlayout/>
    },
    {
      path: '/login',
      element: <Login/>
    },
    {
      path: '/create',
      element: <Create/>
    }

  ])
  return <RouterProvider router={routes}/>

}

export default App